package com.example.kantinfutsalkasir

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

data class Product(val name: String, var price: Int, var stock: Int = 100)
data class CartItem(val product: Product, var qty: Int = 1)

class MainActivity : Activity() {
    private val blue = Color.rgb(8, 79, 137)
    private val prefs by lazy { getSharedPreferences("kantin_futsal", Context.MODE_PRIVATE) }
    private val products = mutableListOf<Product>()
    private val cart = linkedMapOf<String, CartItem>()
    private lateinit var listLayout: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var cartText: TextView
    private lateinit var cashInput: EditText
    private lateinit var changeText: TextView
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadProducts()
        showHome()
    }

    private fun rupiah(value: Int): String =
        NumberFormat.getCurrencyInstance(Locale("in", "ID")).format(value).replace(",00", "")

    private fun loadProducts() {
        val saved = prefs.getString("products", null)
        if (saved != null) {
            val arr = JSONArray(saved)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                products.add(Product(o.getString("name"), o.getInt("price"), o.optInt("stock", 100)))
            }
        } else {
            products.addAll(listOf(
                Product("CLUB KECIL", 3000), Product("CLUB BESAR", 6000),
                Product("FLORIDINA", 5000), Product("GOLDA", 4000),
                Product("ISO PLUS", 5000), Product("JAVANA", 4000),
                Product("MILKU", 4000), Product("POCARI 500ml", 8000),
                Product("POCARI 900ml", 12000), Product("MIE INSTAN", 5000),
                Product("POP MIE", 6000), Product("AIR GALON", 10000)
            ))
            saveProducts()
        }
    }

    private fun saveProducts() {
        val arr = JSONArray()
        products.forEach {
            arr.put(JSONObject().put("name", it.name).put("price", it.price).put("stock", it.stock))
        }
        prefs.edit().putString("products", arr.toString()).apply()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val header = TextView(this).apply {
            text = "KANTIN FUTSAL  •  KASIR"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(blue)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 64))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
        }
        actions.addView(button("TRANSAKSI") { showHome() }, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(button("KELOLA BARANG") { showManage() }, LinearLayout.LayoutParams(0, 48, 1f).apply { leftMargin = 8 })
        root.addView(actions)

        val scroll = ScrollView(this)
        listLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listLayout)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val checkout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 12)
            setBackgroundColor(Color.WHITE)
        }
        cartText = TextView(this).apply { textSize = 14f; setTextColor(Color.DKGRAY) }
        totalText = TextView(this).apply {
            text = "Total: Rp0"; textSize = 21f; setTypeface(null, Typeface.BOLD); setTextColor(blue)
        }
        cashInput = EditText(this).apply {
            hint = "Uang dari pelanggan (angka)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            singleLine = true
        }
        changeText = TextView(this).apply { text = "Kembalian: Rp0"; textSize = 16f; setTextColor(Color.DKGRAY) }
        statusText = TextView(this).apply { textSize = 13f; setTextColor(Color.rgb(30, 110, 50)) }
        cashInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateTotals() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        checkout.addView(cartText)
        checkout.addView(totalText)
        checkout.addView(cashInput)
        checkout.addView(changeText)
        checkout.addView(button("SELESAI & SIMPAN TRANSAKSI") { finishSale() }, LinearLayout.LayoutParams(-1, 48))
        checkout.addView(button("CETAK STRUK (PRINTER BELUM DIHUBUNGKAN)") {
            Toast.makeText(this, "Printer bisa ditambahkan nanti melalui pengembangan berikutnya.", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, 44).apply { topMargin = 6 })
        checkout.addView(statusText)
        root.addView(checkout)
        setContentView(root)
        renderProducts()
        updateTotals()
    }

    private fun renderProducts() {
        listLayout.removeAllViews()
        products.forEach { product ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 8, 12, 8)
                setBackgroundColor(Color.WHITE)
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply {
                text = product.name; textSize = 17f; setTextColor(Color.rgb(35, 35, 35))
                setTypeface(null, Typeface.BOLD)
            })
            info.addView(TextView(this).apply {
                text = "${rupiah(product.price)}  •  Stok: ${product.stock}"; textSize = 14f
                setTextColor(Color.DKGRAY)
            })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("+") {
                val current = cart[product.name]
                if (current == null) cart[product.name] = CartItem(product, 1) else current.qty++
                updateTotals()
            }, LinearLayout.LayoutParams(58, 44))
            listLayout.addView(row)
            listLayout.addView(View(this).apply { setBackgroundColor(Color.rgb(225, 228, 232)) },
                LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun updateTotals() {
        if (!::cartText.isInitialized) return
        val total = cart.values.sumOf { it.product.price * it.qty }
        cartText.text = if (cart.isEmpty()) "Keranjang: belum ada barang" else
            "Keranjang: " + cart.values.joinToString(" • ") { "${it.product.name} x${it.qty}" }
        totalText.text = "Total: ${rupiah(total)}"
        val cash = cashInput.text.toString().toIntOrNull() ?: 0
        changeText.text = if (cash >= total) "Kembalian: ${rupiah(cash - total)}"
                          else "Kurang bayar: ${rupiah(total - cash)}"
    }

    private fun finishSale() {
        if (cart.isEmpty()) {
            Toast.makeText(this, "Pilih barang terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val total = cart.values.sumOf { it.product.price * it.qty }
        val cash = cashInput.text.toString().toIntOrNull() ?: 0
        if (cash < total) {
            Toast.makeText(this, "Uang pelanggan belum cukup.", Toast.LENGTH_SHORT).show()
            return
        }
        val history = JSONArray(prefs.getString("history", "[]"))
        val sale = JSONObject().put("time", System.currentTimeMillis()).put("total", total)
            .put("items", cart.values.joinToString(", ") { "${it.product.name} x${it.qty}" })
        history.put(sale)
        prefs.edit().putString("history", history.toString()).apply()
        cart.values.forEach { it.product.stock = (it.product.stock - it.qty).coerceAtLeast(0) }
        saveProducts()
        cart.clear()
        cashInput.setText("")
        statusText.text = "Transaksi tersimpan • Total ${rupiah(total)}"
        renderProducts()
        updateTotals()
        Toast.makeText(this, "Transaksi berhasil disimpan.", Toast.LENGTH_LONG).show()
    }

    private fun showManage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        root.addView(TextView(this).apply {
            text = "KELOLA BARANG"; textSize = 22f; setTextColor(blue); setTypeface(null, Typeface.BOLD)
        })
        val name = EditText(this).apply { hint = "Nama barang" }
        val price = EditText(this).apply {
            hint = "Harga (angka, contoh 5000)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val stock = EditText(this).apply {
            hint = "Stok awal (contoh 50)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        root.addView(name)
        root.addView(price)
        root.addView(stock)
        root.addView(button("TAMBAH BARANG") {
            val n = name.text.toString().trim()
            val p = price.text.toString().toIntOrNull()
            val s = stock.text.toString().toIntOrNull() ?: 0
            if (n.isBlank() || p == null || p < 0) {
                Toast.makeText(this, "Isi nama dan harga dengan benar.", Toast.LENGTH_SHORT).show()
            } else if (products.any { it.name.equals(n, true) }) {
                Toast.makeText(this, "Nama barang sudah ada.", Toast.LENGTH_SHORT).show()
            } else {
                products.add(Product(n.uppercase(Locale.ROOT), p, s))
                saveProducts()
                Toast.makeText(this, "Barang ditambahkan.", Toast.LENGTH_SHORT).show()
                showManage()
            }
        }, LinearLayout.LayoutParams(-1, 48))
        root.addView(button("KEMBALI KE TRANSAKSI") { showHome() },
            LinearLayout.LayoutParams(-1, 48).apply { topMargin = 8 })
        val scroll = ScrollView(this)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        products.forEach { p ->
            items.addView(TextView(this).apply {
                text = "${p.name} — ${rupiah(p.price)} — stok ${p.stock}"
                textSize = 15f; setTextColor(Color.DKGRAY); setPadding(4, 10, 4, 10)
            })
        }
        scroll.addView(items)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { action() }
        }
    }
}
